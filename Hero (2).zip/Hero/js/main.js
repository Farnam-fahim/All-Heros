function battle(){
	var hero = document.getElementById('hero').value;
	var villian = document.getElementById('villian').value;
	if (hero.toLowerCase() == "fire" && villian.toLowerCase() == "rock" || hero.toLowerCase() == "water" && villian.toLowerCase() == "fire" || hero.toLowerCase() == "rock" && villian.toLowerCase() == "water") {alert("Hero Won")}
		 else if(villian.toLowerCase() == "fire" && hero.toLowerCase() == "rock" || villian.toLowerCase() == "water" && hero.toLowerCase() == "fire" || villian.toLowerCase() == "rock" && hero.toLowerCase() == "water") {alert("Villain won")}
		 	else if(hero.toLowerCase() === villian.toLowerCase()){
		alert("Tie!!!");
	}
}